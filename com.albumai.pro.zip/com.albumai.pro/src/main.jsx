    import React from "react";
import { createRoot } from "react-dom/client";

import App from "./App";

import "./styles/app.css";

const container = document.getElementById("root");

if (!container) {

    throw new Error(

        "Root element (#root) not found."

    );

}

const root = createRoot(container);

root.render(

    <React.StrictMode>

        <App />

    </React.StrictMode>

);

if (import.meta?.hot) {

    import.meta.hot.accept();

}